bcc -ansi -c -o kernal_c.o kernal.c
as86 kernal.asm -o kernal_asm.o
ld86 -o kernal -d kernal_c.o kernal_asm.o
dd if=kernal of=diskc.img bs=512 conv=notrunc seek=3

